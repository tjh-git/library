package com.simple.zj.book.po;



public class Book {
	
	private String id;
	private String tstm;
    private String tsmc;
    private String ywfj;
    private String csmc;
    private String bzzz;
    private String fyzz;
    private String isbn;
    private String cbs;
    private String tsyy;
    private String ylsx;
    private String cbsj;
    private String tsbc;
    private String tskc;
    private String tskb;
    private String yszz;
    private Integer tsys;
    private Double dj;
    private String sfgjs;
    private String sfqj;
    private String lrrp;
    private String userId;
    private String orgId;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTstm() {
		return tstm;
	}
	public void setTstm(String tstm) {
		this.tstm = tstm;
	}
	public String getTsmc() {
		return tsmc;
	}
	public void setTsmc(String tsmc) {
		this.tsmc = tsmc;
	}
	public String getYwfj() {
		return ywfj;
	}
	public void setYwfj(String ywfj) {
		this.ywfj = ywfj;
	}
	public String getCsmc() {
		return csmc;
	}
	public void setCsmc(String csmc) {
		this.csmc = csmc;
	}
	public String getBzzz() {
		return bzzz;
	}
	public void setBzzz(String bzzz) {
		this.bzzz = bzzz;
	}
	public String getFyzz() {
		return fyzz;
	}
	public void setFyzz(String fyzz) {
		this.fyzz = fyzz;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getCbs() {
		return cbs;
	}
	public void setCbs(String cbs) {
		this.cbs = cbs;
	}
	public String getTsyy() {
		return tsyy;
	}
	public void setTsyy(String tsyy) {
		this.tsyy = tsyy;
	}
	public String getYlsx() {
		return ylsx;
	}
	public void setYlsx(String ylsx) {
		this.ylsx = ylsx;
	}
	public String getCbsj() {
		return cbsj;
	}
	public void setCbsj(String cbsj) {
		this.cbsj = cbsj;
	}
	public String getTsbc() {
		return tsbc;
	}
	public void setTsbc(String tsbc) {
		this.tsbc = tsbc;
	}
	public String getTskc() {
		return tskc;
	}
	public void setTskc(String tskc) {
		this.tskc = tskc;
	}
	public String getTskb() {
		return tskb;
	}
	public void setTskb(String tskb) {
		this.tskb = tskb;
	}
	public String getYszz() {
		return yszz;
	}
	public void setYszz(String yszz) {
		this.yszz = yszz;
	}
	public Integer getTsys() {
		return tsys;
	}
	public void setTsys(Integer tsys) {
		this.tsys = tsys;
	}
	public Double getDj() {
		return dj;
	}
	public void setDj(Double dj) {
		this.dj = dj;
	}
	public String getSfgjs() {
		return sfgjs;
	}
	public void setSfgjs(String sfgjs) {
		this.sfgjs = sfgjs;
	}
	public String getSfqj() {
		return sfqj;
	}
	public void setSfqj(String sfqj) {
		this.sfqj = sfqj;
	}
	public String getLrrp() {
		return lrrp;
	}
	public void setLrrp(String lrrp) {
		this.lrrp = lrrp;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
    
    
    
    
}
