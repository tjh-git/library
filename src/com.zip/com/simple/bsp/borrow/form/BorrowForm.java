package com.simple.bsp.borrow.form;

/**
 * Created by 17854 on 2016/6/5.
 */
public class BorrowForm
{
    private String code="";
    private int enable;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getEnable() {
        return enable;
    }

    public void setEnable(int enable) {
        this.enable = enable;
    }
}
