package com.simple.bsp.properties.form;

/**
 * Created by 17854 on 2016/7/2.
 */
public class SchoolAddForm
{
    private String school_id="-99999999";

    public String getSchool_id() {
        return school_id;
    }

    public void setSchool_id(String school_id) {
        this.school_id = school_id;
    }

    private String school_name=null;
    private String school_position=null;
    private String school_contact=null;
    private String school_post=null;
    private String school_tel=null;
    private String school_pass=null;
    private String school_href=null;



    public String getSchool_name() {
        return school_name;
    }

    public void setSchool_name(String school_name) {
        this.school_name = school_name;
    }

    public String getSchool_position() {
        return school_position;
    }

    public void setSchool_position(String school_position) {
        this.school_position = school_position;
    }

    public String getSchool_contact() {
        return school_contact;
    }

    public void setSchool_contact(String school_contact) {
        this.school_contact = school_contact;
    }

    public String getSchool_post() {
        return school_post;
    }

    public void setSchool_post(String school_post) {
        this.school_post = school_post;
    }

    public String getSchool_tel() {
        return school_tel;
    }

    public void setSchool_tel(String school_tel) {
        this.school_tel = school_tel;
    }

    public String getSchool_pass() {
        return school_pass;
    }

    public void setSchool_pass(String school_pass) {
        this.school_pass = school_pass;
    }

    public String getSchool_href() {
        return school_href;
    }

    public void setSchool_href(String school_href) {
        this.school_href = school_href;
    }
}
