package com.simple.bsp.cant.service;

import java.util.List;

public interface IPubCantService {
	public List getAllListByParentId(String parentId);
}
