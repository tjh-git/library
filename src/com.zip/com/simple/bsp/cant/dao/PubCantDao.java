package com.simple.bsp.cant.dao;

import java.util.List;

public interface PubCantDao {
	public List getAllListByParentId(String parentId);
}
