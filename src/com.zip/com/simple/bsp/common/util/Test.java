/**
 * 
 */
package com.simple.bsp.common.util;

/**
 * @author simple
 *
 */
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String ss = NextID.getNextID("user");
		System.out.println("["+ss+"]");

	}

}
