package com.simple.bsp.webservice;

import javax.jws.WebService;

@WebService
public interface Storage {
	
	
	public String storageData(String storageList);

}
