package com.simple.BookManage.Service;

import java.util.List;

/**
 * Created by lovesyxfuffy on 2016/7/2.
 */
public interface AccountService {
    public Object login(String username, String password);
}
